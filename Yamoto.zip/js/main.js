/* ===================== */
/* Header menu toggle    */
/* ===================== */
const menu = document.querySelector('.header__menu');
const overlay = document.querySelector('.header__overlay');
const closeButton = document.querySelector('.header__menu-close');
const openButton = document.querySelector('.header__menu-button');

function toggleMenu(state) {
    menu.classList[state]('active');
    overlay.classList[state]('active');
    document.body.classList[state]('body-menu-overflow');
}

openButton.addEventListener('click', () => toggleMenu('add'));
overlay.addEventListener('click', () => toggleMenu('remove'));
closeButton.addEventListener('click', () => toggleMenu('remove'));

/* ===================== */
/* Form validation       */
/* ===================== */
const forms = document.querySelectorAll('form');

forms.forEach(form => {
    form.addEventListener('submit', e => {
        e.preventDefault();
        const hasError = validateForm(e.target);

        if (!hasError) {
            form.reset();
        }
    });
});

function validateForm(form) {
    let hasError = false;

    form.querySelectorAll('input[type="text"]').forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            hasError = true;

            input.addEventListener('input', handleInput, { once: true });
        }
    });

    return hasError;
}

function handleInput(e) {
    const input = e.target;
    if (input.value.trim()) {
        input.classList.remove('error');
    }
}

/* ===================== */
/* Modal                 */
/* ===================== */
const modal = document.querySelector('.modal');
const modalClose = document.querySelector('.modal__close');

function toggleModal(state) {
    modal.classList[state]('active');
    document.body.classList[state]('body-overflow');
}

modalClose.addEventListener('click', () => toggleModal('remove'));
modal.addEventListener('click', e => {
    if (!e.target.closest('.modal__content')) {
        toggleModal('remove');
    }
});

/* ===================== */
/* Select dropdown       */
/* ===================== */
let activeSelect = null;

document.addEventListener('click', e => {
    const target = e.target;
    const selectButton = target.closest('.select__button');
    const listButton = target.closest('.select__list-button');

    if (selectButton) {
        selectButton.classList.add('active');
        activeSelect = selectButton;
    } else if (listButton && activeSelect) {
        activeSelect.querySelector('.select__active-value').innerText = listButton.innerText;
        activeSelect.classList.remove('active');
        activeSelect = null;
    } else if (activeSelect && !target.closest('.select')) {
        activeSelect.classList.remove('active');
        activeSelect = null;
    }

    /* ================= */
    /* Extra interactions*/
    /* ================= */
    if (target.closest('.catalog__button') || target.closest('.header__box-button')) {
        toggleModal('add');
    }

    if (target.closest('.header__link')) {
        toggleMenu('remove');
    }
});

/* ================= */
/* Fancybox          */
/* ================= */

Fancybox.bind('[data-fancybox="generators"]', {
    Thumbs: false,
    Toolbar: true,
});